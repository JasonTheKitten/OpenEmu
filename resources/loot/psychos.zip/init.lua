_OSVERSION="PsychOS 2.0a3-1ef6d5d"
do
syslog = {}
syslog.emergency = 0
syslog.alert = 1
syslog.critical = 2
syslog.error = 3
syslog.warning = 4
syslog.notice = 5
syslog.info = 6
syslog.debug = 7

-- function syslog(msg, level, service) -- string number string -- -- Output *msg* to the system log, with severity *level*, from *service*.
local rdprint=dprint or function() end
setmetatable(syslog,{__call = function(_,msg, level, service)
 level, service = level or syslog.info, service or (os.taskInfo(os.pid()) or {}).name or "unknown"
 rdprint(string.format("syslog: [%s:%d/%d] %s",service,os.pid(),level,msg))
 computer.pushSignal("syslog",msg, level, service)
end})
function dprint(...)
 for k,v in pairs({...}) do
  syslog(v,syslog.debug)
 end
end
end

do
local tTasks,nPid,nTimeout,cPid = {},1,0.25,0 -- table of tasks, next process ID, event timeout, current PID
function os.spawn(f,n) -- function string -- number -- creates a process from function *f* with name *n*
 tTasks[nPid] = {
  c=coroutine.create(function()
   local rt = {pcall(f)}
   if not rt[1] then
    syslog(rt[2])
   end
   computer.pushSignal("process_finished",os.pid(),table.unpack(rt))
  end), -- actual coroutine
  n=n, -- process name
  p=nPid, -- process PID
  P=cPid, -- parent PID
  e={} -- environment variables
 }
 if tTasks[cPid] then
  for k,v in pairs(tTasks[cPid].e) do
   tTasks[nPid].e[k] = tTasks[nPid].e[k] or v
  end
 end
 nPid = nPid + 1
 return nPid - 1
end
function os.kill(pid) -- number -- -- removes process *pid* from the task list
 tTasks[pid] = nil
end
function os.pid() -- -- number -- returns the current process' PID
 return cPid
end
function os.tasks() -- -- table -- returns a table of process IDs
 local rt = {}
 for k,v in pairs(tTasks) do
  rt[#rt+1] = k
 end
 return rt
end
function os.taskInfo(pid) -- number -- table -- returns info on process *pid* as a table with name and parent values
 pid = pid or os.pid()
 if not tTasks[pid] then return false end
 return {name=tTasks[pid].n,parent=tTasks[pid].P}
end
function os.sched() -- the actual scheduler function
 os.sched = nil
 while #tTasks > 0 do
  local tEv = {computer.pullSignal(nTimeout)}
  for k,v in pairs(tTasks) do
   if coroutine.status(v.c) ~= "dead" then
    cPid = k
    coroutine.resume(v.c,table.unpack(tEv))
   else
    tTasks[k] = nil
   end
  end
 end
end
function os.setenv(k,v) -- set's the current process' environment variable *k* to *v*, which is passed to children
 if tTasks[cPid] then
  tTasks[cPid].e[k] = v
 end
end
function os.getenv(k) -- gets a process' *k* environment variable
 if tTasks[cPid] then
  return tTasks[cPid].e[k]
 end
end
function os.getTimeout()
 return nTimeout
end
function os.setTimeout(n)
 if type(n) == "number" and n >= 0 then
  nTimeout = n
  return true
 end
 return false
end
end

-- shamelessly stolen from plan9k

buffer = {}

function buffer.new(mode, stream) -- string table -- table -- create a new buffer in mode *mode* backed by stream object *stream*
 local result = {
  mode = {},
  stream = stream,
  bufferRead = "",
  bufferWrite = "",
  bufferSize = math.max(512, math.min(8 * 1024, computer.freeMemory() / 8)),
  bufferMode = "full",
  readTimeout = math.huge
 }
 mode = mode or "r"
 for i = 1, unicode.len(mode) do
  result.mode[unicode.sub(mode, i, i)] = true
 end
 local metatable = {
  __index = buffer,
  __metatable = "file"
 }
 return setmetatable(result, metatable)
end

local function badFileDescriptor()
 return nil, "bad file descriptor"
end

function buffer:close()
 if self.mode.w or self.mode.a then
  self:flush()
 end
 self.closed = true
 return self.stream:close()
end

function buffer:flush()
 local result, reason = self.stream:write(self.bufferWrite)
 if result then
  self.bufferWrite = ""
 else
  if reason then
   return nil, reason
  else
   return badFileDescriptor()
  end
 end

 return self
end

function buffer:lines(...)
 local args = table.pack(...)
 return function()
  local result = table.pack(self:read(table.unpack(args, 1, args.n)))
  if not result[1] and result[2] then
   error(result[2])
  end
  return table.unpack(result, 1, result.n)
 end
end

function buffer:read(...)
 local timeout = computer.uptime() + self.readTimeout

 local function readChunk()
  if computer.uptime() > timeout then
   error("timeout")
  end
  local result, reason = self.stream:read(self.bufferSize)
  if result then
   self.bufferRead = self.bufferRead .. result
   return self
  else -- error or eof
   return nil, reason
  end
 end

 local function readBytesOrChars(n)
  n = math.max(n, 0)
  local len, sub
  if self.mode.b then
   len = rawlen
   sub = string.sub
  else
   len = unicode.len
   sub = unicode.sub
  end
  local buffer = ""
  repeat
   if len(self.bufferRead) == 0 then
    local result, reason = readChunk()
    if not result then
     if reason then
      return nil, reason
     else -- eof
      return #buffer > 0 and buffer or nil
     end
    end
   end
   local left = n - len(buffer)
   buffer = buffer .. sub(self.bufferRead, 1, left)
   self.bufferRead = sub(self.bufferRead, left + 1)
  until len(buffer) == n
  
  return buffer
 end

 local function readNumber()
  local len, sub
  if self.mode.b then
   len = rawlen
   sub = string.sub
  else
   len = unicode.len
   sub = unicode.sub
  end
  local buffer = ""
  local first = true
  local decimal = false
  local last = false
  local hex = false
  local pat = "^[0-9]+"
  local minbuf = 3 -- "+0x" (sign + hexadecimal tag)
  -- this function is used to read trailing numbers (1e2, 0x1p2, etc)
  local function readnum(checksign)
   local _buffer = ""
   local sign = ""
   while true do
    if len(self.bufferRead) == 0 then
     local result, reason = readChunk()
     if not result then
      if reason then
       return nil, reason
      else -- eof
       return #_buffer > 0 and (sign .. _buffer) or nil
      end
     end
    end
    if checksign then
     local _sign = sub(self.bufferRead, 1, 1)
     if _sign == "+" or _sign == "-" then
      -- "eat" the sign (Rio Lua behaviour)
      sign = sub(self.bufferRead, 1, 1)
      self.bufferRead = sub(self.bufferRead, 2)
     end
     checksign = false
    else
     local x,y = string.find(self.bufferRead, pat)
     if not x then
      break
     else
      _buffer = _buffer .. sub(self.bufferRead, 1, y)
      self.bufferRead = sub(self.bufferRead, y + 1)
     end
    end
   end
   return #_buffer > 0 and (sign .. _buffer) or nil
  end
  while true do
   if len(self.bufferRead) == 0 or len(self.bufferRead) < minbuf then
    local result, reason = readChunk()
    if not result then
     if reason then
      return nil, reason
     else -- eof
      return #buffer > 0 and tonumber(buffer) or nil
     end
    end
   end
   -- these ifs are here so we run the buffer check above
   if first then
    local sign = sub(self.bufferRead, 1, 1)
    if sign == "+" or sign == "-" then
     -- "eat" the sign (Rio Lua behaviour)
     buffer = buffer .. sub(self.bufferRead, 1, 1)
     self.bufferRead = sub(self.bufferRead, 2)
    end
    local hextag = sub(self.bufferRead, 1, 2)
    if hextag == "0x" or hextag == "0X" then
     pat = "^[0-9A-Fa-f]+"
     -- "eat" the 0x, see https://gist.github.com/SoniEx2/570a363d81b743353151
     buffer = buffer .. sub(self.bufferRead, 1, 2)
     self.bufferRead = sub(self.bufferRead, 3)
     hex = true
    end
    minbuf = 0
    first = false
   elseif decimal then
    local sep = sub(self.bufferRead, 1, 1)
    if sep == "." then
     buffer = buffer .. sep
     self.bufferRead = sub(self.bufferRead, 2)
     local temp = readnum(false) -- no sign
     if temp then
      buffer = buffer .. temp
     end
    end
    if not tonumber(buffer) then break end
    decimal = false
    last = true
    minbuf = 1
   elseif last then
    local tag = sub(self.bufferRead, 1, 1)
    if hex and (tag == "p" or tag == "P") then
     local temp = sub(self.bufferRead, 1, 1)
     self.bufferRead = sub(self.bufferRead, 2)
     local temp2 = readnum(true) -- this eats the next sign if any
     if temp2 then
      buffer = buffer .. temp .. temp2
     end
    elseif tag == "e" or tag == "E" then
     local temp = sub(self.bufferRead, 1, 1)
     self.bufferRead = sub(self.bufferRead, 2)
     local temp2 = readnum(true) -- this eats the next sign if any
     if temp2 then
      buffer = buffer .. temp .. temp2
     end
    end
    break
   else
    local x,y = string.find(self.bufferRead, pat)
    if not x then
     minbuf = 1
     decimal = true
    else
     buffer = buffer .. sub(self.bufferRead, 1, y)
     self.bufferRead = sub(self.bufferRead, y + 1)
    end
   end
  end
  return tonumber(buffer)
 end

 local function readLine(chop)
  if not self.mode.t then
   local start = 1
   while true do
    local l = self.bufferRead:find("\n", start, true)
    if l then
     local result = self.bufferRead:sub(1, l + (chop and -1 or 0))
     self.bufferRead = self.bufferRead:sub(l + 1)
     return result
    else
     start = #self.bufferRead
     local result, reason = readChunk()
     if not result then
      if reason then
       return nil, reason
      else -- eof
       local result = #self.bufferRead > 0 and self.bufferRead or nil
       self.bufferRead = ""
       return result
      end
     end
    end
   end
  else
   -- ?????
   io.write("\27[s\27[8m")
   local pos, buffer, hIndex = 1, "", 0
   self.history = self.history or {}
   local function redraw()
    io.write(string.format("\27[u%s \27[u\27[%iC",buffer,(#buffer-pos)+1))
   end
   while true do
    char = readBytesOrChars(1)
    if char == "\27" then
     if readBytesOrChars(1) == "[" then
      local args = {""}
      repeat
       char = readBytesOrChars(1)
       if char:match("%d") then
        args[#args] = args[#args]..char
       else
        args[#args] = tonumber(args[#args])
        args[#args+1] = ""
       end
      until not char:match("[%d;]")
      if char == "C" then -- right
       if pos > 1 then
        pos = pos - 1
       end
      elseif char == "D" then -- left
       if pos <= #buffer then
        pos = pos + 1
       end
      elseif char == "A" then -- up
       hIndex = hIndex + 1
       io.write("\27[u"..(" "):rep(buffer:len()+1))
       buffer = self.history[1+#self.history-hIndex] or buffer
       pos = 1
      elseif char == "B" then -- down
       hIndex = hIndex - 1
       io.write("\27[u"..(" "):rep(buffer:len()+1))
       if hIndex == 0 then
        hIndex = hIndex - 1
        buffer = ""
       end
       buffer = self.history[1+#self.history-hIndex] or buffer
       pos = 1
      end
      hIndex = math.max(math.min(hIndex,#self.history),0)
     end
    elseif char == "\8" then -- backspace
     if #buffer > 0 and pos <= #buffer then
      buffer = buffer:sub(1, (#buffer - pos)) .. buffer:sub((#buffer - pos) + 2)
     end
    elseif char == "\1" then -- ^A, go to start of line
     pos = buffer:len()+1
    elseif char == "\5" then -- ^E, go to end of line
     pos = 1
    elseif char == "\2" then -- ^B, back one word
     local nc = buffer:reverse():find(" ",pos+1)
     pos = nc or #buffer+1
    elseif char == "\6" then -- ^F, forward one word
     local nc = buffer:find(" ",math.max(#buffer-pos+3,0))
     pos = (nc and #buffer-nc+2) or 1
    elseif char == "\13" or char == "\10" or char == "\n" then -- return / newline
     io.write("\n")
     self.history[#self.history+1] = buffer
     if #self.history > (self.maxhistory or 16) then table.remove(self.history,1) end
     if chop then buffer = buffer .. "\n" end
     return buffer
    else
     buffer = buffer:sub(1, (#buffer - pos) + 1) .. char .. buffer:sub((#buffer - pos) + 2)
    end
    redraw()
   end
  end
 end

 local function readAll()
  repeat
   local result, reason = readChunk()
   if not result and reason then
    return nil, reason
   end
  until not result -- eof
  local result = self.bufferRead
  self.bufferRead = ""
  return result
 end

 local function read(n, format)
  if type(format) == "number" then
   return readBytesOrChars(format)
  else
   if type(format) ~= "string" or unicode.sub(format, 1, 1) ~= "*" then
    error("bad argument #" .. n .. " (invalid option)")
   end
   format = unicode.sub(format, 2, 2)
   if format == "n" then
    return readNumber()
   elseif format == "l" then
    return readLine(true)
   elseif format == "L" then
    return readLine(false)
   elseif format == "a" then
    return readAll()
   else
    error("bad argument #" .. n .. " (invalid format)")
   end
  end
 end

 if self.mode.w or self.mode.a then
  self:flush()
 end

 local results = {}
 local formats = table.pack(...)
 if formats.n == 0 then
  return readLine(true)
 end
 for i = 1, formats.n do
  local result, reason = read(i, formats[i])
  if result then
   results[i] = result
  elseif reason then
   return nil, reason
  end
 end
 return table.unpack(results, 1, formats.n)
end

function buffer:seek(whence, offset)
 whence = tostring(whence or "cur")
 assert(whence == "set" or whence == "cur" or whence == "end",
  "bad argument #1 (set, cur or end expected, got " .. whence .. ")")
 offset = offset or 0
 checkArg(2, offset, "number")
 assert(math.floor(offset) == offset, "bad argument #2 (not an integer)")

 if self.mode.w or self.mode.a then
  self:flush()
 elseif whence == "cur" then
  offset = offset - #self.bufferRead
 end
 local result, reason = self.stream:seek(whence, offset)
 if result then
  self.bufferRead = ""
  return result
 else
  return nil, reason
 end
end

function buffer:setvbuf(mode, size)
 mode = mode or self.bufferMode
 size = size or self.bufferSize

 assert(mode == "no" or mode == "full" or mode == "line",
  "bad argument #1 (no, full or line expected, got " .. tostring(mode) .. ")")
 assert(mode == "no" or type(size) == "number",
  "bad argument #2 (number expected, got " .. type(size) .. ")")

 self.bufferMode = mode
 self.bufferSize = size

 return self.bufferMode, self.bufferSize
end

function buffer:getTimeout()
 return self.readTimeout
end

function buffer:setTimeout(value)
 self.readTimeout = tonumber(value)
end

function buffer:write(...)
 if self.closed then
  return badFileDescriptor()
 end
 local args = table.pack(...)
 for i = 1, args.n do
  if type(args[i]) == "number" then
   args[i] = tostring(args[i])
  end
  checkArg(i, args[i], "string")
 end

 for i = 1, args.n do
  local arg = args[i]
  local result, reason

  if self.bufferMode == "full" then
   if self.bufferSize - #self.bufferWrite < #arg then
    result, reason = self:flush()
    if not result then
     return nil, reason
    end
   end
   if #arg > self.bufferSize then
    result, reason = self.stream:write(arg)
   else
    self.bufferWrite = self.bufferWrite .. arg
    result = self
   end

  elseif self.bufferMode == "line" then
   local l
   repeat
    local idx = arg:find("\n", (l or 0) + 1, true)
    if idx then
     l = idx
    end
   until not idx
   if l or #arg > self.bufferSize then
    result, reason = self:flush()
    if not result then
     return nil, reason
    end
   end
   if l then
    result, reason = self.stream:write(arg:sub(1, l))
    if not result then
     return nil, reason
    end
    arg = arg:sub(l + 1)
   end
   if #arg > self.bufferSize then
    result, reason = self.stream:write(arg)
   else
    self.bufferWrite = self.bufferWrite .. arg
    result = self
   end

  else -- self.bufferMode == "no"
   result, reason = self.stream:write(arg)
  end

  if not result then
   return nil, reason
  end
 end

 return self
end

function os.chdir(p) -- string -- boolean string -- changes the current working directory of the calling process to the directory specified in *p*, returning true or false, error
 if not (p:sub(1,1) == "/") then
  local np = {}
  for k,v in pairs(fs.segments(os.getenv("PWD").."/"..p)) do
   if v == ".." then
    np[#np] = nil
   else
    np[#np+1] = v
   end
  end
  p = "/"..table.concat(np,"/")
 end
 if fs.list(p) then
  os.setenv("PWD",p)
 else
  return false, "no such directory"
 end
end

do
fs = {}
local fsmounts = {}

-- basics
function fs.segments(path) -- string -- table -- Splits *path* on each /
 local segments = {}
 for segment in path:gmatch("[^/]+") do
  segments[#segments+1] = segment
 end
 return segments
end
function fs.resolve(path) -- string -- string string -- Resolves *path* to a specific filesystem mount and path
 if not path or path == "." then path = os.getenv("PWD") end
 if path:sub(1,1) ~= "/" then path=(os.getenv("PWD") or "").."/"..path end
 local segments, rpath, rfs= fs.segments(path)
 local rc = #segments
 for i = #segments, 1, -1 do
  if fsmounts[table.concat(segments, "/", 1, i)] ~= nil then
   return table.concat(segments, "/", 1, i), table.concat(segments, "/", i+1)
  end
 end
 return "/", table.concat(segments,"/")
end

-- generate some simple functions
for k,v in pairs({"makeDirectory","exists","isDirectory","list","lastModified","remove","size","spaceUsed","spaceTotal","isReadOnly","getLabel"}) do
 fs[v] = function(path)
  local fsi,path = fs.resolve(path)
  return fsmounts[fsi][v](path)
 end
end

local function fread(self,length)
 return fsmounts[self.fs].read(self.fid,length)
end
local function fwrite(self,data)
 return fsmounts[self.fs].write(self.fid,data)
end
local function fseek(self,dist)
 return fsmounts[self.fs].seek(self.fid,dist)
end
local function fclose(self)
 return fsmounts[self.fs].close(self.fid)
end

function fs.open(path,mode) -- string string -- table -- Opens file *path* with mode *mode*, returning a file object.
 mode = mode or "rb"
 local fsi,path = fs.resolve(path)
 if not fsmounts[fsi] then return false end
 local fid = fsmounts[fsi].open(path,mode)
 if fid then
  local fobj = {["fs"]=fsi,["fid"]=fid,["seek"]=fseek,["close"]=fclose}
  if mode:find("r") then
   fobj.read = fread
  end
  if mode:find("w") then
   fobj.write = fwrite
  end
  return fobj
 end
 return false
end

function fs.copy(from,to) -- string string -- boolean -- copies a file from *from* to *to*
 local of = fs.open(from,"rb")
 local df = fs.open(to,"wb")
 if not of or not df then
  return false
 end
 local tmp
 repeat
  tmp = of:read(2048)
  df:write(tmp or "")
 until not tmp
 df:close()
 of:close()
 return true
end

function fs.rename(from,to) -- string string -- boolean -- Moves file *from* to *to*
 local ofsi, opath = fs.resolve(from)
 local dfsi, dpath = fs.resolve(to)
 if ofsi == dfsi then
  fsmounts[ofsi].rename(opath,dpath)
  return true
 end
 if not fs.copy(from,to) then return false end
 if not fs.remove(from) then return false end
 return true
end

function fs.mount(path,proxy) -- string table -- boolean -- Mounts the filesystem *proxy* to the mount point *path* if it is a directory. BYO proxy.
 if fs.isDirectory(path) and not fsmounts[table.concat(fs.segments(path),"/")] then
  fsmounts[table.concat(fs.segments(path),"/")] = proxy
  return true
 end
 return false, "path is not a directory"
end
function fs.umount(path) -- string -- -- Unmounts filesystem from *path*.
 local fsi,_ = fs.resolve(path)
 fsmounts[fsi] = nil
end

function fs.mounts() -- -- table -- Returns a table containing the mount points of all mounted filesystems
 local rt = {}
 for k,v in pairs(fsmounts) do
  rt[#rt+1] = k,v.address or "unknown"
 end
 return rt
end

function fs.address(path) -- string -- string -- Returns the address of the filesystem at a given path, if applicable; do not expect a sensical response
 local fsi,_ = fs.resolve(path)
 return fsmounts[fsi].address
end
function fs.type(path) -- string -- string -- Returns the component type of the filesystem at a given path, if applicable
 local fsi,_ = fs.resolve(path)
 return fsmounts[fsi].type or "filesystem"
end

fsmounts["/"] = component.proxy(computer.tmpAddress())
fs.makeDirectory("temp")
if computer.getBootAddress then
 fs.makeDirectory("boot")
 fs.mount("boot",component.proxy(computer.getBootAddress()))
end

end

io = {}

function io.open(path,mode) -- string string -- table -- Open file *path* in *mode*. Returns a buffer object.
 local f,e = fs.open(path, mode)
 if not f then return false, e end
 return buffer.new(mode,f)
end

function io.input(fd) -- table -- table -- Sets the default input stream to *fd* if provided, either as a buffer as a path. Returns the default input stream.
 if type(fd) == "string" then
  fd=io.open(fd,"rbt")
 end
 if fd then
  os.setenv("STDIN",fd)
 end
 return os.getenv("STDIN")
end
function io.output(fd) -- table -- table -- Sets the default output stream to *fd* if provided, either as a buffer as a path. Returns the default output stream.
 if type(fd) == "string" then
  fd=io.open(fd,"wb")
 end
 if fd then
  os.setenv("STDOUT",fd)
 end
 return os.getenv("STDOUT")
end

function io.read(...) -- Reads from the default input stream.
 return io.input():read(...)
end
function io.write(...) -- Writes its arguments to the default output stream.
 io.output():write(...)
end

function print(...) -- Writes each argument to the default output stream, separated by newlines.
 for k,v in ipairs({...}) do
  io.write(tostring(v).."\n")
 end
end

devfs = {}
devfs.files = {}
devfs.fds = {}
devfs.nextfd = 0
devfs.component = {}

local function rfalse()
 return false
end
local function rzero()
 return 0
end
function devfs.component.getLabel()
 return "devfs"
end
devfs.component.spaceUsed, devfs.component.spaceTotal, devfs.component.isReadOnly, devfs.component.isDirectory,devfs.component.size, devfs.component.setLabel = rzero, rzero, rfalse, rfalse, rzero, rfalse

function devfs.component.exists(fname)
 return devfs.files[fname] ~= nil
end

function devfs.component.list()
 local t = {}
 for k,v in pairs(devfs.files) do
  t[#t+1] = k
 end
 return t
end

function devfs.component.open(fname, mode)
 fname=fname:gsub("/","")
 if devfs.files[fname] then
  local r,w,c,s = devfs.files[fname](mode)
  devfs.fds[devfs.nextfd] = {["read"]=r or rfalse,["write"]=w or rfalse,["seek"]=s or rfalse,["close"]=c or rfalse}
  devfs.nextfd = devfs.nextfd + 1
  return devfs.nextfd - 1
 end
 return false
end

function devfs.component.read(fd,count)
 if devfs.fds[fd] then
  return devfs.fds[fd].read(count)
 end
end
function devfs.component.write(fd,data)
 if devfs.fds[fd] then
  return devfs.fds[fd].write(data)
 end
end
function devfs.component.close(fd)
 if devfs.fds[fd] then
  devfs.fds[fd].close()
 end
 devfs.fds[fd] = nil
end
function devfs.component.seek(fd,...)
 if devfs.fds[fd] then
  return devfs.fds[fd].seek(...)
 end
end
function devfs.component.remove(fname)
end
devfs.component.address = "devfs"
devfs.component.type = "devfs"

function devfs.register(fname,fopen) -- string function -- -- Register a new devfs node with the name *fname* that will run the function *fopen* when opened. This function should return a function for read, a function for write, function for close, and optionally, a function for seek, in that order.
 devfs.files[fname] = fopen
end

fs.makeDirectory("/dev")
fs.mount("/dev",devfs.component)

devfs.register("null",function()
 return function() end, function() end, function() end
end)


devfs.register("syslog",function()
 return function() end, syslog, function() end end)

function loadfile(p) -- string -- function -- reads file *p* and returns a function if possible
 local f = io.open(p,"rb")
 local c = f:read("*a")
 f:close()
 return load(c,p,"t")
end
function runfile(p,...) -- string -- -- runs file *p* with arbitrary arguments in the current thread
 return loadfile(p)(...)
end

_G.package = {}
package.path="/boot/lib/?.lua;/pkg/lib/?.lua;/boot/lib/?/init.lua;/pkg/lib/?/init.lua;./?;./?.lua;./?/init.lua"
package.loaded = {buffer=buffer, component=component, computer=computer, coroutine=coroutine, fs=fs, math=math, os=os, package=package, string=string, table=table}
package.alias = {filesystem="fs"}
function require(f,force) -- string boolean -- table -- searches for a library with name *f* and returns what the library returns, if possible. if *force* is set, loads the library even if it is cached
 f=package.alias[f] or f
 if not package.loaded[f] or force then
  local ln = f:gsub("%.","/")
  for d in package.path:gmatch("[^;]+") do
   local p = d:gsub("%?",ln)
   if fs.exists(p) and not fs.isDirectory(p) then
    package.loaded[f] = runfile(p)
    break
   end
  end
 end
 if package.loaded[f] then
  return package.loaded[f]
 end
 error("library not found: "..f)
end
function reload(f) -- string -- table -- Reloads library *f* from disk into memory.
 return require(f,true)
end


_OSVERSION=_OSVERSION or "PsychOS 2"

os.spawn(function()
 os.setenv("PWD","/boot")
 io.input("/dev/null")
 io.output("/dev/syslog")
 local f = io.open("/boot/cfg/hostname","rb")
 local hostname = computer.address():sub(1,8)
 if f then
  hostname = f:read("*l")
  f:close()
 end
 os.setenv("HOSTNAME",hostname)
 syslog(string.format("Hostname set to %s",hostname))
 local pids = {}
 local rc = require "rc"
 for k,v in pairs(rc.cfg.enabled) do
  pids[v] = -1
 end
 while true do
  for k,v in pairs(pids) do
   if not os.taskInfo(v) then
    syslog("Starting service "..k)
    pids[k] = rc.start(k)
   end
  end
  coroutine.yield()
 end
end, "init")

os.sched()
