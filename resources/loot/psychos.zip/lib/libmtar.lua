local mtar = {}
local versions = {}
versions[0] = {nlf = ">I2", flf = ">I2"} -- original version format
versions[1] = {nlf = ">I2", flf = ">I8"} -- extended file size format
mtar.versions = versions

local function cleanPath(path)
 local pt = {}
 for segment in path:gmatch("[^/]+") do
  if segment == ".." then
   pt[#pt] = nil
  elseif segment ~= "." then
   pt[#pt+1] = segment
  end
 end
 return table.concat(pt,"/")
end

function mtar.genHeader(fname,len,version) -- string number -- string -- generate a header for file *fname* when provided with file length *len*
 version=version or 1
 return string.format("\255\255%s%s%s%s", string.char(version), string.pack(versions[version].nlf,fname:len()), fname, string.pack(versions[version].flf,len))
end

function mtar.iter(stream) -- table -- function -- Given buffer *stream*, returns an iterator suitable for use with *for* that returns, for each iteration, the file name, a function to read from the file, and the length of the file.
 local remain = 0
 local function read(n)
  local rb = stream:read(math.min(n,remain))
  remain = remain - rb:len()
  return rb
 end
 return function()
  while remain > 0 do
   remain=remain-#stream:read(math.min(remain,2048))
  end
  local version = 0
  local nlen = string.unpack(">I2", stream:read(2) or "\0\0")
  if nlen == 0 then
   return
  elseif nlen == 65535 then -- versioned header
   version = string.byte(stream:read(1))
   nlen = string.unpack(versions[version].nlf, stream:read(string.packsize(versions[version].nlf)))
  end
  local name = cleanPath(stream:read(nlen))
  remain = string.unpack(versions[version].flf, stream:read(string.packsize(versions[version].flf)))
  return name, read, remain
 end
end

return mtar
