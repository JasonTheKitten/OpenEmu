-- file browser app --

local fs = require("filesystem")

local dir = "/"

local app = {
  w = 40
}
